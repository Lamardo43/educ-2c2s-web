cube = lambda x: # complete the lambda function 

def fibonacci(n):
    # return a list of fibonacci numbers

if __name__ == '__main__':
    n = int(input())
    print(list(map(cube, fibonacci(n))))
