import math

class Point:
    def __init__(self, x, y, z):
        # your code here        
        
    def __sub__(self, no):
        # your code here        
        
    def dot(self, no):
        # your code here        
        
    def cross(self, no):
        # your code here        
        
    def absolute(self):
        return math.sqrt(self.x ** 2 + self.y ** 2 + self.z ** 2)

def plane_angle(a, b, c, d):
    # your code here

if __name__ == '__main__':
    # your code here
