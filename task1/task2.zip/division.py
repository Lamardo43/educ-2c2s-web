a, b = int(input()), int(input())

if (b == 0):
    print("devision by zero")
    exit()
print(a // b)
print(a / b)