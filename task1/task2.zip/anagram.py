s1 = input()
s2 = input()

sorted_s1 = sorted(s1)
sorted_s2 = sorted(s2)

if sorted_s1 == sorted_s2:
    print("YES")
else:
    print("NO")
