string = input()
fragments = string.split()
result = "-".join(fragments)
print(result)
